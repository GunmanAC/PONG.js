let hit = false

//variáveis da bolinha
let xBolinha = 300;
let yBolinha = 200;
let diametro = 15;
let raio = diametro / 2;

//variáveis da velocidade da bolinha
let velocidadeXBolinha = 13/2;
let velocidadeYBolinha = 13/2;

//variáveis da raquete
let xRaquete = 5;
let yRaquete = 150;
let alturaRaquete = 90;
let larguraRaquete = 10;

//variáveis raquete do oponente
let xRaqueteP2 = 585;
let yRaqueteP2 = 150;
let alturaRaqueteP2 = 90;
let larguraRaqueteP2 = 10;

//variáveis Do Placar Bonito
let larguraPlacar = 90
let alturaPlacar = 10
let xPlacar = 278
let yPlacar = 10

//variáveis dos pontos
let MeusPontos = 0
let PontosOponente = 0

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaçãoBolinha();
  verificarColisãoBorda();
  mostraRaquete();
  movimentaRaquete();
  colisãoRaquete();
  raqueteOponente();
  movimentaP2();
  colisãoRaqueteP2();
  placar();
  Pontos();
}

function mostraBolinha(){
  circle(xBolinha, yBolinha, diametro);
}

function movimentaçãoBolinha(){
  xBolinha = velocidadeXBolinha + xBolinha;
  yBolinha = velocidadeYBolinha + yBolinha;
}

function verificarColisãoBorda(){
  if (xBolinha  + raio > width || xBolinha - raio < 0){
  velocidadeXBolinha *= -1;
  }
 
  if  (yBolinha + raio > height || yBolinha - raio < 0){
    velocidadeYBolinha *= -1;
  }
}

function mostraRaquete(){

  rect(xRaquete, yRaquete, larguraRaquete, alturaRaquete);

}

function movimentaRaquete(){
  if (keyIsDown(87)){
   yRaquete -= 10;
  }
if (keyIsDown(83)){
   yRaquete += 10;
 }
} 
 function raqueteOponente(){
   rect(xRaqueteP2, yRaqueteP2, larguraRaqueteP2, alturaRaqueteP2);
 }

function movimentaP2(){
  if (keyIsDown(40)){
    yRaqueteP2 += 10}
  if (keyIsDown(38)){
    yRaqueteP2 -= 10}
  
  }
function colisãoRaquete(){
  hit =
  collideRectCircle(xRaquete, yRaquete, larguraRaquete, alturaRaquete, xBolinha, yBolinha, raio);

if (hit){
  velocidadeXBolinha *= -1;
  }
}
  function colisãoRaqueteP2(){
    hit =
  collideRectCircle(xRaqueteP2, yRaqueteP2, larguraRaqueteP2, alturaRaqueteP2, xBolinha, yBolinha, raio);

if (hit){
  velocidadeXBolinha *= -1;
    
    }
  }
  function placar(){
    fill(255)
    text(MeusPontos, 278, 10);
    text(PontosOponente, 300, 10);
  }
function Pontos(){
  if (xBolinha - raio < 0){
    PontosOponente += 1;
  }
  if (xBolinha + raio > 600){
    MeusPontos += 1;
  }
}
function placarBonito(){
  rect(xPlacar, yPlacar, alturaPlacar, larguraPlacar)
}






